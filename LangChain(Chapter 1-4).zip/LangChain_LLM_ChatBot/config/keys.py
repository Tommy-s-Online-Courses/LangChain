
class Keys:
    OPENAI_API_KEY = "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"
    PINECONE_KEY = "f1edac4b-ec66-4999-8e04-2db6b4d41498"
    HUGGINGFACEHUB_API_TOKEN = "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"